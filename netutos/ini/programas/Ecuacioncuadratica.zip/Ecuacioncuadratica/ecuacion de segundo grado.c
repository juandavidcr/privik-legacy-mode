#include<stdio.h>
#include<stdlib.h>

int main(void)
{
    //Inicializar variables//
    int a,b,c;
    float x1,x2;
    
    printf("Programa que calcula las ecuaciones de segundo grado\n");
    printf("Proporciona el valor de a: ");
    scanf("%d",&a);
    printf("Proporciona el valor de b: ");
    scanf("%d",&b);
    printf("Proporciona el valor de c: ");
    scanf("%d",&c);
    
    x1=(-b+(sqrt((b*b)-(4*a*c))))/2*a;
    x2=(-b-(sqrt((b*b)-(4*a*c))))/2*a;
    printf("Las raices son %f, %f ",x1,x2);
    system("PAUSE");
    
    return 0;
}
