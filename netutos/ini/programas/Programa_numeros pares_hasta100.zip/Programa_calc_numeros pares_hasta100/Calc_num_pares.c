#include <stdio.h>
#include <stdlib.h>
//Programa que imprime la suma de todos los numeros enteros pares que hay del 1 -100

main()
{
      //construir los numeros pares comprendidos entre 1 y 100
     int k=50;
     int pares[k], suma=0, resultado=0;
     int i,lim=100;
     //inicializamos las variables
     printf("Este programa calcula la suma de los numeros enteros pares comprendidos\n");
     printf("entre 1-100\n");
     i=1;  //inicializamos i
     //Pares es un arreglo de enteros donde k = 
     for (pares[k]=i; i<=lim; i++)
     {
   //aqui se encuentra si un numero es par o no y se discrimina el que no es par
         if  ( i%2 == 0 )  
         {
         printf("%d",i);   //imprime numeros pares   
         printf("\n");     //salto de linea despues de cada impresion
         
         resultado=i+resultado;      //se acumula en una sumatoria y se guarda en resultado
         }
         
         
         
     }      //fin para que encuentra los pares y los imprime en pantalla
     for (k=0; k<=lim; k++)  //fot para imprimir el resultado de la sumatoria
         {
             
             printf("la suma de los numeros pares es %d\n",resultado); //aqui se imprime la sumatoria
             break; //cuando se encuentra se sale del ciclo mediante un break
               
         }
 
     //pausa en el sistema para ver el resultado
     system("pause");
}
