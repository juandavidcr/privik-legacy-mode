//SYDNEY M�RQUEZ ESCOTO
//Este programa calcula el m.c.m. o el m.c.d.de 2 numeros dados por el usuario.

#include<stdio.h> 

int mcd (int,int);//declaracion de la funcion mcd 
int mcm (int,int);//declaracion de la funcion mcm 
int main (void) 

{ 

int num[2],n=0,res; 
char opc=1; 
int cmb; 

while(opc!= 'd') //inicia el ciclo while
{ 
	printf("\n" ); 
	printf("\n" ); 
	printf(" MENU PRINCIPAL \n\n" ); 
	printf(" a)Ingresar numero\n" ); 
	printf(" b)Calcular m.c.m\n" ); 
	printf(" c)Calcular m.c.d\n" ); 
	printf(" d)Finalizar\n\n" ); 
	printf(" Ingrese la opcion: " ); 
	scanf("%c", &opc); 

switch (opc)//para ejecutar la opci�n introducida 
{ 
	case 'a': 
	if (n==0||n==1) 
{ 
		printf("\nIngrese un numero entero: " ); 
		scanf("%d", &num[n]); 
		printf("El numero ha sido ingreasdo" ); 
		n++; 
} 
	else //si el usuario introduce dos o m�s veces alguna opcion
{ 
	printf("\nEste programa solo opera con\ndos numeros.\n" ); 
	printf("Para sobre-escribir uno de los dos numeros\n" ); 
	printf("Ingrese la ubicacion del numero a cambiar\n" ); 
	printf("o 3 para salir\n" ); 
	printf("1: %d 2: %d ::",num[0],num[1]); 
	scanf("%d",&cmb); 
switch (cmb) //reescribe el numero en la memoria 
{ 
case 1: 
	printf("Ingrese el numero: " ); 
	scanf("%d",&num[0]); 
break; 

case 2: 
	printf("Ingrese el numero: " ); 
	scanf("%d",&num[1]); 
break; 

	case 3: 
break; 

default: 
break; 
} 

} 
break; 

case 'b': 
	res=mcm(num[0],num[1]); //llama la funcion mcm 
	printf("\nEl M.C.M de %d y %d es %d \n", num[0], num[1], res); 
break; 

case 'c': 
	res=mcd(num[0],num[1]); //llama la funcion mcd 
	printf("\nEl M.C.D de %d y %d es %d \n", num[0], num[1], res); 
break; 

case 'd': //cierrra el programa
continue; 
break; 

default: 
	printf("\nla opcion no es valida\n" ); 
break; 
} 
while ((opc=getchar())!='\n');//limpiar el buffer 
} 

return 0; 
} 

int mcd (a,b) 
{ 
int res, n = 1; 


while(n<=a&&n<=b)//cicla para el m.c.d 
{ 
while(a%n==0&&b%n==0) 
{ 
	res=n; 
	n++; 
} 
	n++; 
} 


return res;//regresa el m.c.d 
} 

int mcm (a,b) 
{ 
int res; 
	res = (a*b)/mcd(a,b);//formula para obtener m.c.m 

return res;//regresa el m.c.m 
} 
