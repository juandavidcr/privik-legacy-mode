#include<stdio.h>
#include<stdlib.h>
//Programacion estructurada//
int main ()
{
    //Calculando la media de tres valores//
    float a,b,c,M;
    printf("Introdce valor a: ");
    scanf("%f",&a);
    printf("Introdce valor b: ");
    scanf("%f",&b);
    printf("Introdce valor c: ");
    scanf("%f",&c);
    M=(a+b+c)/3; //Calculamos la media de los 3 valores
    
    printf("La media de los valores es: %.2f",M);
    system("PAUSE");
    return 0;
}
