#include <stdio.h>
#include <conio.h>

int main()
{
   FILE *p;
   int i;
   char nombre[100];
   p= fopen("prueba.txt","w");
  
   for (i=1; i != 5; i++)  //5<i
   {
      printf("Deme un nombre: ");
      gets(nombre);
      fprintf(p, "%d\t%s\n",i,nombre);    
   }
   fclose(p);
   printf("El programa termino normalmente");
   getch();
   return 0;    
}
