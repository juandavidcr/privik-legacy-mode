#include<stdio.h>
#include<stdlib.h>
#include<math.h>


int main()
{
    //Programa para calcular:
    
    //Valor absoluto
    
    float x,y,va,l,s,e,p;
    
    printf("Introdce valor x: ");
    scanf("%f",&x);
    va=fabs(x);
    printf("El valor absoluto es: %f \n",va);
    
    //Logoraitmo//
    
    printf("El logaritmo es: %f \n",log10(x));
    
    //Seno//
    
    printf("El seno de x es: %f \n",sin(x));
    
    //Constante e//
    
    printf("La constate e elevada es: %f \n",exp(x));
    
    //Potencia de x a la y//
    
    printf("Ingresa valor de y: ");
    scanf("%f",&y);
    
    printf("La potencia de x a la y es: %.2f \n",pow(x,y));
    
    system("PAUSE");
    return 0;
}
