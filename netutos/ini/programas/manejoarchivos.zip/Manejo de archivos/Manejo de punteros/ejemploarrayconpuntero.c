#include<stdio.h>
/*funcion que rellena de unos un arreglo de enteros*/

void rellenar(int *p, int n);

void rellenar(int *p, int n)
{
    int i,v;//inicializamos en 1
    for(i=0;i<n;i++)
    {
       *(p+i) = v;
       v= v+1;        //es igual p[i]=1 == *(p++)=1        
    }     
}

int main ()
{
    int A[8];
    int i;
    printf("Programa que demuestra el uso de punteros\n");
    rellenar(A,8);    //A es una direccion y 8 el tama�o del arreglo
    for(i=0; i<8; i++)
    {
        printf("direccion en memoria: %d \t->",&i);     
        printf("elemento %d: %d\n",i,A[i]);         
    }
    getch();    
    return 0;    
}
