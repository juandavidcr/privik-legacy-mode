//Elaborado por: Jorge Elías Vigil Santos
//Una tienda donde, en la compra de tres productos, si se tiene credencial se descuenta el de menor precio.
//Este programa tiene la intención de ilustrar el uso de funciones para realizar varias operaciones.
#include<stdio.h> //Cabeceras (donde se incluyen las bibliotecas)
//Declaracion de funciones
int suma(int, int, int);	//func suma: recibe 3 enteros (int) y devuelve un entero
int resta(int, int);		//func resta: recibe 2 enteros (int) y devuelve un entero
int compara(int, int, int);	//func compara: recibe 3 enteros (int) y devueve un entero
int resp(char);			//func resp: recibe un caracter (char) y devuelve un entero
//Funcion principal
void main() {
	//Declaracin de variables locales de tipo entero (int) y caracter (char)
	int precio1, precio2, precio3, sum, menor, respu, res;
	char respuesta[1];
	printf("�Bienvenido!\n");
	printf("Este programa te pedira que ingreses el precio de tres productos:\n");
	printf("Ingresa el precio del primer producto:\n$ ");
	scanf("%i", &precio1);
	printf("Ahora ingresa el precio del segundo producto:\n$ ");
	scanf("%i", &precio2);
	printf("Por ultimo, ingresa el precio del tercer producto:\n$ ");
	scanf("%i", &precio3);
	printf("Cuentas con membresia de la tienda? (s/n):\n");
	scanf("%s", respuesta);

	menor = compara(precio1, precio2, precio3); //Estas son variables a las que se le asignan los resultados de cada funcion

	respu = resp(respuesta[0]);		//Estas son variables a las que se le asignan los resultados de cada funcion

	sum = suma(precio1, precio2, precio3);	//Estas son variables a las que se le asignan los resultados de cada funcion

	res = resta(sum, menor);		//Estas son variables a las que se le asignan los resultados de cada funcion

	if (respu == 1) {
	
		printf("Debido a que cuentas con membresia se te descontara el producto con menor precio\n");
		printf("El producto de menor precio cuesta: %i\n", menor);
		printf("El total a pagar es de: $ %i\n", res);
		printf("Gracias por su preferencia!\n");
	}
	else {
		printf("Debido a que no cuentas con membresia no se realizara ningun descuento\n");
		printf("El total a pagar es de: $ %i\n", sum);
		printf("Gracias por su preferencia!\n");
	}
	system("pause");
} //Fin de la funcion principal
//Esta funcion determina la suma de los tres precios
int suma(int precio1, int precio2, int precio3) {

	int suma;

	suma = precio1 + precio2 + precio3;

	return suma;
}
//Esta funcion realiza la resta del menor de los precios al total de la cuenta
int resta(int sum, int menor) {

	int resta;

	resta = sum - menor;

	return resta;
}
//Esta funcion determina el valor de la respuesta mediante una variable de tipo booleano
int resp(char respuesta) {

	if (respuesta != 's') {
		return 0;
	}
	else {
		return 1;
	}
}
//Esta funcion compara los tres precios y determina cual es el menor
int compara(int precio1, int precio2, int precio3) {

	if  (precio1 < precio2 && precio1 < precio3) {		
		return precio1;
	}	

	if (precio2 < precio1 && precio2 < precio3) {
		return precio2;
	}
	else {
		return precio3;
	}
}
