#include <stdio.h>
#include <string.h>
#pragma hdrstop
#pragma argsused
/*Programa que realiza el promedio a*/
int main(int argc, char* argv[])
{  
   int suma,sumatoria;  //variables que almacenan la suma de los datos ingresados por teclado
   int contador = 0;    //inicializo variable en 0.
   char sigue;//varible de tipo caracter
   float promedio;

   promedio = 0;// se inicia
   sigue = 's';  //variable char
   printf("Este programa calcula el promedio dentro de un loop while para ingresar datos y hasta que oprima 'n' se dejan de ingresar elementos\n");
   while (sigue == 's')
   //es verdadero si se compara del mismo tipo de dato
   { 
	 printf("Ingresa dato: \n");
	 scanf("%d",&sumatoria);
	 printf("Si desea ingresar otro numero presiona 's' si no presiona 'n'\n");
	 fflush(stdin);//depurar memoria del teclado
	 sigue = getch();//aqui se realiza la comparacion de tipo caracter con 'sigue'
	 promedio = sumatoria+promedio; //se calcula el promedio
	 contador++;//servira para saber sobre cuanto se hara la division.
   }
   promedio = promedio/contador;
   printf("El promedio es: %.2f \n",promedio);//imprime el resultado final
   system("pause");
   return 0;
}
