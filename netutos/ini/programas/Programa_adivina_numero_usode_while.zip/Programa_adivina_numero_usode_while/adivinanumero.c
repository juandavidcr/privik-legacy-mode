#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main() 
{
     int escalones = 39;
     int num;
     printf("Adivina\n");
     printf("En que numero estoy pensando?: ");
     scanf("%d",&num);
     
     while( num != escalones ){
            printf("No es esa la respuesta correcta, por favor escriba otra respuesta\n");
            scanf("%d", &num);
            
            }
     printf("Felicidades ha adivinado!\n");
     system("pause");
}
