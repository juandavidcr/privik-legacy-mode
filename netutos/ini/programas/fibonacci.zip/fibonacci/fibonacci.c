//Elaborado por: Jorge Elías Vigil Santos, correcciones: Juan David Contreras Ruiz
//Este programa realizara la serie de Fibonacci hasta la cifra dada por el usuario.
//
#include<stdio.h> //Cabeceras (donde se incluyen las bibliotecas)
void main() {	//Funcion principal

	int limite, a = 1, b = 1, fib, cont;	//Variables locales

	printf("bienvenido!\n");
	printf("Este programa realizara la serie de fibonacci, te pedira que ingreses el numero de cifras que desees que despliege.\n");
	printf("Cuantos numeros de Fibonacci deseas desplegar?:\n");
	scanf("%i", &limite);
    printf("\nEsta es la sucesion numeros: ");
	 //0,1,1,2,3,5,8,13
	printf("0,%d, %d,",a,b);
	for (cont = 1; cont < limite - 2; cont ++) {	
        //Se ingresa a un ciclo que se ejecutara hasta que "cont" llegue al limite dado por el usuario
		fib = a + b;
        printf("%i,", fib);//fib corresponde a la formula de la serie de Fibonacci
	//Se imprime el número de Fibonacci actual
		a = b;			//Por asignación destructiva "a" borra el valor que tenía y se sustituye por el valor de actual "b"
		b = fib;		//Por asignación destructiva "b" borra el valor que tenía  y se sustituye por el valor de "fib"
	}
	
	printf("\n");
	system("pause");
}//Fin de funcion principal
