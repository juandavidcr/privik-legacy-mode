//SYDNEY M�RQUEZ ESCOTO
// Descripcion: Programa que lea una frase en una cadena de caracteres y cuente 
//el n�mero de vocales que contiene.


#include <stdio.h>

#define MAX_CADENA 100

int main()
{
	char cadena[MAX_CADENA];
	int contador1,contador;
	//int vocales[5];
	int vocales[5]={0};
	char tvocales[]={'a','e','i','o','u'};

   do
   {
   	printf("\nIntroduce una frase que quieras que se haga un conteo de vocales: ");
      scanf("%s",&cadena);

		contador=0;
		while (cadena[contador]!='\0')
		{
			for(contador1=0;contador1<5;contador1++)
			if(cadena[contador]==tvocales[contador1])
			vocales[contador1]++;
			contador++;
		}

		for(contador=0;contador<5;contador++)
		{
   		printf("\nLa %c aparece en \"%s\" %d veces",tvocales[contador],
         													cadena,vocales[contador]);
		}
   }while(vocales);


   getchar();
   return 1;
}

